import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class CashOutForm extends StatefulWidget {
  const CashOutForm({super.key});

  @override
  _CashOutFormState createState() => _CashOutFormState();
}

class _CashOutFormState extends State<CashOutForm> {
  final _formKey = GlobalKey<FormState>();
  String cashOutPurpose = 'Bills';
  String paymentMethod = 'Cash';
  DateTime selectedDate = DateTime.now();
  final TextEditingController _amountController = TextEditingController();
  TextEditingController payeeController = TextEditingController();
  TextEditingController notesController = TextEditingController();




  String currentUserId = FirebaseAuth.instance.currentUser!.uid;
  double? currentBalance;
  double? totalExpense;
  double? totalIncome;

  storeData() async {
    double amountOut = double.tryParse(_amountController.text.toString().trim()) ?? 0;

    String incomeTransactionId = FirebaseFirestore.instance.collection('users').doc().id;
    final query = FirebaseFirestore.instance.collection("users").doc(currentUserId);
    var data = await query.get();
    currentBalance = data['currentBalance'].toDouble() ?? 0;
    totalExpense = data['totalExpense'].toDouble() ?? 0;
    totalIncome = data['totalIncome'].toDouble() ?? 0;

    if (amountOut > currentBalance!) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('You do not have enough balance!'),
          backgroundColor: Colors.red,
        ),
      );
      return;
    }

    double newBalance = currentBalance! - amountOut;

    await Future.wait([
      query.update({
        "currentBalance": newBalance,
        "totalExpense": totalExpense! + amountOut,
        "totalIncome": totalIncome! ,
      }),
      query.collection("transactions").doc('expense').collection('Expense_records').doc(incomeTransactionId).set({
        'cashOut Purpose' : cashOutPurpose,
        'ExpenseAmount': amountOut,
        'time': DateTime.now(),
        'month': DateTime.now().month,
        'payment Method' : paymentMethod,
        'Payee Name' : payeeController.text,
        'Comments': notesController.text,
      }),
    ]);

    setState(() {
      _amountController.clear();
      notesController.clear();

    });
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cash Out Form'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              // Cash Out Purpose
              DropdownButtonFormField<String>(
                value: cashOutPurpose,
                decoration: const InputDecoration(labelText: 'Purpose of Cash Out'),
                items: ['Bills', 'Rent', 'Shopping', 'Travel', 'Food']
                    .map((purpose) {
                  return DropdownMenuItem(value: purpose, child: Text(purpose));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    cashOutPurpose = value!;
                  });
                },
              ),
              const SizedBox(height: 16),

              // Amount
              TextFormField(
                controller: _amountController,
                decoration: const InputDecoration(labelText: 'Amount'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the amount';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Date Picker
              ListTile(
                title: Text("Date: ${selectedDate.toLocal()}".split(' ')[0]),
                trailing: const Icon(Icons.calendar_today),
                onTap: () => _selectDate(context),
              ),
              const SizedBox(height: 16),

              // Payment Method
              DropdownButtonFormField<String>(
                value: paymentMethod,
                decoration: const InputDecoration(labelText: 'Payment Method'),
                items: ['Cash', 'Bank Transfer', 'Credit Card', 'Mobile Wallet', 'Cheque']
                    .map((method) {
                  return DropdownMenuItem(value: method, child: Text(method));
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    paymentMethod = value!;
                  });
                },
              ),
              const SizedBox(height: 16),

              // Payee Name
              TextFormField(
                controller: payeeController,
                decoration: const InputDecoration(labelText: 'Payee Name'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter the payee name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),

              // Notes/Description
              TextFormField(
                controller: notesController,
                decoration: const InputDecoration(labelText: 'Notes'),
                maxLines: 3,
              ),
              const SizedBox(height: 16),

              // Submit Button
              ElevatedButton(
                onPressed: () {
                  storeData();
                  if (_formKey.currentState!.validate()) {
                    // Handle form submission
                    print('Cash Out Recorded');
                  }
                },
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Date Picker Function
  _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null && picked != selectedDate)
      setState(() {
        selectedDate = picked;
      });
  }
}
